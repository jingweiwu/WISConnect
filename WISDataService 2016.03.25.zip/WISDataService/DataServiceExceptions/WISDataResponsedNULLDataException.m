//
//  WISNetworkResponsedNULLDataException.m
//  WISConnect
//
//  Created by Jingwei Wu on 3/1/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#import "WISDataResponsedNULLDataException.h"

@implementation WISDataResponsedNULLDataException

@end
