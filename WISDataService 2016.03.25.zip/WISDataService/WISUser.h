//
//  WISUser.h
//  WISConnect
//
//  Created by Jingwei Wu on 2/21/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#import <Foundation/Foundation.h>

@class UIImage, WISFileInfo;

@interface WISUser : NSObject <NSCopying>

@property (readwrite, strong) NSString *userName;
@property (readwrite, strong) NSString *fullName;
@property (readwrite, strong) NSString *telephoneNumber;
@property (readwrite, strong) NSString *cellPhoneNumber;
@property (readwrite, strong) NSString *roleCode;
@property (readwrite, strong) NSString *roleName;

@property (readwrite, strong) UIImage *thumbnailPhoto;
@property (readwrite, strong) NSMutableDictionary<NSString *, WISFileInfo *> *imagesInfo;

- (instancetype)init; // __attribute__((unavailable("init method not available")));

- (instancetype)initWithUserName:(NSString *)userName
                            name:(NSString *)fullName
                 telephoneNumber:(NSString *)telephoneNumber
                 cellPhoneNumber:(NSString *)cellPhoneNumber
                        roleCode:(NSString *)roleCode
                        roleName:(NSString *)roleName
                   andImagesInfo:(NSMutableDictionary<NSString *, WISFileInfo *> *)imagesInfo;

@end
