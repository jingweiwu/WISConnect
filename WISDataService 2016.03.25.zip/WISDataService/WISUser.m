//
//  WISUser.m
//  WISConnect
//
//  Created by Jingwei Wu on 2/21/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WISUser.h"
#import "WISFileInfo.h"

@interface WISUser ()

@end


@implementation WISUser

- (instancetype)init {
    return [self initWithUserName:@""
                              name:@""
                   telephoneNumber:@""
                   cellPhoneNumber:@""
                          roleCode:@""
                          roleName:@""
                    andImagesInfo:[NSMutableDictionary dictionary]];
}

- (instancetype)initWithUserName:(NSString *)userName
                            name:(NSString *)fullName
                 telephoneNumber:(NSString *)telephoneNumber
                 cellPhoneNumber:(NSString *)cellPhoneNumber
                        roleCode:(NSString *)roleCode
                        roleName:(NSString *)roleName
                   andImagesInfo:(NSMutableDictionary<NSString *, WISFileInfo *> *)imagesInfo {
    
    if (self = [super init]) {
        _userName = userName;
        _fullName = fullName;
        _telephoneNumber = telephoneNumber;
        _cellPhoneNumber = cellPhoneNumber;
        _roleCode = roleCode;
        _roleName = roleName;
        
        _thumbnailPhoto = [[UIImage alloc] init];
        _imagesInfo = imagesInfo;
      
    }
    return self;
}

- (id) copyWithZone:(NSZone *)zone {
    WISUser * user = [[[self class] allocWithZone:zone] initWithUserName:[self.userName copy]
                                                                    name:[self.fullName copy]
                                                         telephoneNumber:[self.telephoneNumber copy]
                                                         cellPhoneNumber:[self.cellPhoneNumber copy]
                                                                roleCode:[self.roleCode copy]
                                                                roleName:[self.roleName copy]
                                                           andImagesInfo:[self.imagesInfo copy]];
    
    user.thumbnailPhoto = [self.thumbnailPhoto copy];
    return user;
}


@end
