//
//  WISDataManager.m
//  WISConnect
//
//  Created by Jingwei Wu on 2/25/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#import "WISDataManager.h"



NSString *const WISErrorDomain = @"WISErrorDomain";
//NSDictionary *const WISRoleCodeDictionary = @{@"CTO":@"技术主管",
//                                                     @"FactoryManager":@"厂级负责人",
//                                                     @"FactoryMinister":@"前方部长",
//                                                     @"DutyManager":@"值班经理",
//                                                     @"Engineer":@"工程师",
//                                                     @"Operator":@"生产人员",
//                                                     @"Electrician":@"电工",};

@interface WISDataManager ()

@property (weak) WISNetworkService *networkService;

@property (readwrite, strong) WISUser *currentUser;
@property (readwrite, strong) NSString *networkRequestToken;

/// 角色对照表
@property (readwrite,strong) NSArray<NSString *> const *roleCodes;
@property (readwrite,strong) NSDictionary<NSString *, NSString *> const *roleNameDictionary;

/// 登录时用
@property (readwrite, strong) NSString *temporaryUserName;
@property (readwrite, strong) NSString *temporaryRequestToken;

@property (readwrite, strong) NSMutableDictionary <NSString*, WISUser*> *users;
/// @brief key是WISMainenanceTask类中的TaskID属性
@property (readwrite, strong) NSMutableDictionary <NSString*, WISMaintenanceTask*> *maintenanceTasks;

@property (readwrite, strong) NSMutableDictionary <NSString *, NSString *> *processSegments;


/// 以下method暂不开放给使用者
///
// 保存图片 (本地／服务器)
- (void) storeImageWithImages:(NSDictionary<NSString *, UIImage *> *)images
      uploadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
            completionHandler:(WISSystemFileOperationHandler)handler;



// 获取图片(本地／服务器)
- (void) obtainImageWithImagesInfo:(NSDictionary<NSString *, WISFileInfo *> *)imagesInfo
         downloadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                 completionHandler:(WISSystemFileOperationHandler)handler;


// 上传图片 (至服务器)
- (void) uploadImageWithImages:(NSDictionary<NSString *, UIImage *> *)images
             progressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
             completionHandler:(WISSystemDataTransmissionHandler)handler;


// 下载图片 (自服务器)
- (void) downloadImageWithImageLocations:(NSArray<NSString *> *)imagesRemoteLocation
                       progressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                       completionHandler:(WISSystemDataTransmissionHandler)handler;


@end


@implementation WISDataManager

#pragma mark - Initializer
+ (instancetype) sharedInstance {
    static WISDataManager *sharedDataManagerInstance;
    
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken,^(void) {
        sharedDataManagerInstance = [[self alloc] init];
    });
    
    return sharedDataManagerInstance;
}


- (instancetype) init {
    if (self = [super init]) {
        _networkService = [WISNetworkService sharedInstance];
        
        _currentUser = [[WISUser alloc] init];
        
        _networkRequestToken = nil;
        
        
        _roleCodes = @[@"CTO", @"FactoryManager", @"FactoryMinister", @"DutyManager", @"Engineer", @"Operator", @"Electrician",];
        _roleNameDictionary =  @{_roleCodes[TechManager]:@"技术主管",
                                 _roleCodes[FactoryManager]:@"厂级负责人",
                                 _roleCodes[FieldManager]:@"前方部长",
                                 _roleCodes[DutyManager]:@"值班经理",
                                 _roleCodes[Engineer]:@"工程师",
                                 _roleCodes[Operator]:@"生产人员",
                                 _roleCodes[Technician]:@"电工",};
        
        _temporaryUserName = nil;
        _temporaryRequestToken = nil;

        _users = [NSMutableDictionary <NSString*, WISUser*> dictionary];
        _maintenanceTasks = [NSMutableDictionary <NSString*, WISMaintenanceTask*> dictionary];
        _processSegments = [NSMutableDictionary <NSString*, NSString*> dictionary];
        
        // _imageStore = [WISLocalDocumentImageStore sharedInstance];
    }
    return self;
}
 


#pragma mark - SignIn Operation

- (void) signInWithUserName:(NSString *)userName
                andPassword:(NSString *)password
          completionHandler:(WISSystemSignInHandler)handler {
    
    NSDictionary * signInParams = nil;
    
    if ([userName isEqual: @""] || userName == nil || [password isEqual: @""] || password == nil) {
        NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeWrongFuncParameters andCallbackError:nil];
        
        handler(FALSE, err);
        
        [[NSNotificationCenter defaultCenter]
         postNotificationName:WISSystemSignInFailedNotification
         object:(NSError *)err];
        
        [self.opDelegate signInFailedWithError:err];
        return;
        
    } else {
        
        self.temporaryUserName = userName;
        self.temporaryRequestToken = password;
        
        signInParams = [NSDictionary
         dictionaryWithObjectsAndKeys:userName, @"UserName", password, @"PassWord", nil];
        
        [self.networkService dataRequestWithRequestType:SignIn
                                                 params:signInParams
                                          andUriSetting:nil
         completionHandler:^(RequestType requestType, NSData *responsedData, NSError *error) {
             if (!responsedData) {
                 NSLog(@"SignIn 请求异常，原因: %@", @"返回的数据为空");
                 
                 NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData andCallbackError:error];
                 
                 handler(FALSE, err);
                 
                 [[NSNotificationCenter defaultCenter]
                  postNotificationName:WISSystemSignInFailedNotification
                  object:(NSError *)err];
                 
                 [self.opDelegate signInFailedWithError:err];
                 
             } else {
             
                 NSError *parseError;
                 NSDictionary *parsedData = nil;
                 
                 parsedData = [NSJSONSerialization JSONObjectWithData:responsedData
                                                              options:NSJSONReadingMutableContainers
                                                                error:&parseError];
                 
                 if (!parsedData || parseError) {
                     NSLog(@"SignIn 操作解析内容失败，原因: %@", parseError);
                     
                     NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                     
                     handler(FALSE, err);
                     
                     [[NSNotificationCenter defaultCenter]
                      postNotificationName:WISSystemSignInFailedNotification
                      object:(NSError *)err];
                     
                     [self.opDelegate signInFailedWithError:err];
                     
                 } else {
                     
                     SignInResult result = (SignInResult)[parsedData[@"Result"] integerValue];
                     id parsedImageURL = nil;
                     NSError *err;
                     
                     switch (result) {
                         case SignInSuccessful:
                             _currentUser.userName = self.temporaryUserName;
                             _currentUser.fullName = (parsedData[@"UserInfo"])[@"Name"];
                             _currentUser.roleCode = (parsedData[@"UserInfo"])[@"RoleCode"];
                             _currentUser.roleName = (parsedData[@"UserInfo"])[@"RoleName"];
                             
                             parsedImageURL = (parsedData[@"UserInfo"])[@"ImageURL"];
                             _currentUser.imagesInfo = [NSMutableDictionary dictionary];
                             
                             if(parsedImageURL || ((NSNull *)parsedImageURL == [NSNull null])) {
                                 // do nothing
                             } else {
                                 /// 根据接口的不同构建不同的PHOTO LIST. 现在的接口是仅返回一个String
                                 NSString *imageURL = (NSString *)parsedImageURL;
                                 WISFileInfo *imageInfo = [self produceFileInfoWithFileRemoteURL:imageURL];
                                 [_currentUser.imagesInfo addEntriesFromDictionary:[NSDictionary dictionaryWithObject:imageInfo forKey:imageInfo.fileName]];
                             }
                             
                             _networkRequestToken = self.temporaryRequestToken;
                             
                             //清空DataManager中的相关项
                             [_users removeAllObjects];
                             [_maintenanceTasks removeAllObjects];
                             [_processSegments removeAllObjects];
                             
                             // roleCodeDictionary is changed to immutable variable 2016.03.08
//                             if ([self.roleCodeDictionary valueForKey:_currentUser.roleCode]) {
//                                 self.roleCodeDictionary[_currentUser.roleCode] = (parsedData[@"UserInfo"])[@"RoleName"];
//                             } else {
//                                 [self.roleCodeDictionary setValue:(parsedData[@"UserInfo"])[@"RoleName"]
//                                                            forKey:_currentUser.roleCode];
//                             }
                             
                             [[NSNotificationCenter defaultCenter]
                              postNotificationName:WISSystemSignInSucceededNotification
                              object:self];
                             
                             [self.opDelegate signInSucceeded];
                             handler(YES, nil);
                             break;
                             
                         case UserNotExist:
                             err = [self produceErrorObjectWithWISErrorCode:ErrorCodeSignInUserNotExist andCallbackError:nil];
                             
                             handler(FALSE, err);
                             
                             [[NSNotificationCenter defaultCenter]
                              postNotificationName:WISSystemSignInFailedNotification
                              object:(NSError *)err];
                             
                             [self.opDelegate signInFailedWithError:err];
                             break;
                             
                         case WrongPassword:
                             err = [self produceErrorObjectWithWISErrorCode:ErrorCodeSignInWrongPassword andCallbackError:nil];
                             
                             handler(FALSE, err);
                             
                             [[NSNotificationCenter defaultCenter]
                              postNotificationName:WISSystemSignInFailedNotification
                              object:(NSData *)responsedData];
                             
                             [self.opDelegate signInFailedWithError:err];
                             
                             break;
                             
                         default:
                             break;
                     }
                 }
             }
         }];
    }
}


- (void) updateProcessSegmentWithCompletionHandler:(WISMaintenanceTaskUpdateInfoHandler)handler {
    
    NSDictionary * updateParams = nil;
    
    if ([self.currentUser.userName isEqual: @""] || self.currentUser.userName == nil
            || [self.networkRequestToken isEqual: @""] || self.networkRequestToken == nil) {
        
        NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeNoCurrentUserInfo andCallbackError:nil];
        handler(FALSE, err, @"", nil);
        
        [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateProcessSegmentSFailedNotification
                                                            object:(NSError *)err];
        [self.opDelegate updateProcessSegmentFailedWithError:err];
        
        return;
        
    } else {
        
        updateParams = [NSDictionary dictionaryWithObjectsAndKeys:self.currentUser.userName, @"UserName",
                        self.networkRequestToken, @"PassWord", nil];
        
        [self.networkService dataRequestWithRequestType:UpdateMaintenanceAreas
                                                 params:updateParams
                                          andUriSetting:nil
        completionHandler:^(RequestType requestType, NSData *responsedData, NSError *error) {
            if (!responsedData) {
                NSLog(@"Update Process Segment 请求异常，原因: %@", @"返回的数据为空");
                
                NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData andCallbackError:error];
                handler(FALSE, err, @"", nil);
              
                [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateProcessSegmentSFailedNotification
                                                                    object:(NSError *)err];
                [self.opDelegate updateProcessSegmentFailedWithError:err];
              
            } else {
                
                NSError *parseError;
                NSDictionary *parsedData = nil;
                
                parsedData = [NSJSONSerialization JSONObjectWithData:responsedData
                                                             options:NSJSONReadingMutableContainers
                                                               error:&parseError];
                
                if (!parsedData || parseError) {
                    NSLog(@"Update Process Segment 操作解析内容失败，原因: %@", parseError);
                    
                    NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                    handler(FALSE, err, @"", nil);
                    
                    [[NSNotificationCenter defaultCenter]
                     postNotificationName:WISUpdateProcessSegmentSFailedNotification
                     object:(NSError *)err];
                    
                    [self.opDelegate updateProcessSegmentFailedWithError:err];
                    
                } else {
                    
                    RequestResult result = (RequestResult)[parsedData[@"Result"] integerValue];
                    NSArray *segments = nil;
                    NSError *err;
                    
                    NSMutableDictionary *updatedData = [NSMutableDictionary dictionary];
                    
                    switch (result) {
                        case RequestSuccessful:
                            segments = parsedData[@"Areas"];
                            
                            if(segments.count > 0) {
                                for(NSDictionary *segment in segments) {
                                    if(![self.processSegments valueForKey:[NSString stringWithFormat:@"%@", segment[@"AreaID"]]]) {
                                        [self.processSegments setValue:segment[@"AreaName"]
                                                                forKey:[NSString stringWithFormat:@"%@", segment[@"AreaID"]]];
                                    }
                                    [updatedData setValue:segment[@"AreaName"] forKey:[NSString stringWithFormat:@"%@", segment[@"AreaID"]]];
                                }
                            }
                            
                            [[NSNotificationCenter defaultCenter]
                             postNotificationName:WISUpdateProcessSegmentSucceededNotification
                             object:updatedData];
                            
                            [self.opDelegate updateProcessSegmentSucceeded];
                            handler(YES, nil, NSStringFromClass([updatedData class]), updatedData);
                            break;
                            
                        case RequestFailed:
                            err = [self produceErrorObjectWithWISErrorCode:ErrorCodeInvalidOperation andCallbackError:nil];
                            handler(FALSE, err, @"", nil);
                            
                            [[NSNotificationCenter defaultCenter]
                             postNotificationName:WISUpdateProcessSegmentSFailedNotification
                             object:(NSError *)err];
                            
                            [self.opDelegate updateProcessSegmentFailedWithError:err];
                            break;
                            
                        default:
                            break;
                    }
                }
            }
        }];
    }
}


#pragma mark - Update User Information

- (void) updateContactUserInfoWithCompletionHandler:(WISMaintenanceTaskUpdateInfoHandler)handler {
    [self updateUserInfoWithRequsetType:UpdateContactUserInfo completionHandler:handler];
}


- (void) updateRelavantUserInfoWithCompletionHandler:(WISMaintenanceTaskUpdateInfoHandler)handler {
    [self updateUserInfoWithRequsetType:UpdateRelavantUserInfo completionHandler:handler];
}


- (void) updateUserInfoWithRequsetType:(RequestType)requestType completionHandler:(WISMaintenanceTaskUpdateInfoHandler)handler {
    
    NSDictionary * updateParams = nil;
    
    if ([self.currentUser.userName isEqual: @""] || self.currentUser.userName == nil
        || [self.networkRequestToken isEqual: @""] || self.networkRequestToken == nil) {
        
        NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeNoCurrentUserInfo andCallbackError:nil];
        handler(FALSE, err, @"", nil);
        
        if (requestType == UpdateContactUserInfo) {
            [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateContactUserInfoFailedNotification object:(NSError *)err];
            [self.opDelegate updateContactUserInfoFailedWithError:err];
            
        } else if(requestType == UpdateRelavantUserInfo) {
            [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateRelavantUserInfoFailedNotification object:(NSError *)err];
            [self.opDelegate updateRelavantUserInfoFailedWithError:err];
        }
        
        return;
        
    } else {
        
        updateParams = [NSDictionary dictionaryWithObjectsAndKeys:self.currentUser.userName, @"UserName",
                        self.networkRequestToken, @"PassWord", nil];
        
        [self.networkService dataRequestWithRequestType:requestType
                                                 params:updateParams
                                          andUriSetting:nil
         completionHandler:^(RequestType requestType, NSData *responsedData, NSError *error) {
              if (!responsedData) {
                  NSLog(@"Update User Info 请求异常，原因: %@", @"返回的数据为空");
                  
                  NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData andCallbackError:error];
                  handler(FALSE, err, @"", nil);
                  
                  if (requestType == UpdateContactUserInfo) {
                      [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateContactUserInfoFailedNotification object:(NSError *)err];
                      [self.opDelegate updateContactUserInfoFailedWithError:err];
                      
                  } else if(requestType == UpdateRelavantUserInfo) {
                      [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateRelavantUserInfoFailedNotification object:(NSError *)err];
                      [self.opDelegate updateRelavantUserInfoFailedWithError:err];
                  }
                  
              } else {
             
                  NSError *parseError;
                  NSDictionary *parsedData = nil;
                  
                  parsedData = [NSJSONSerialization JSONObjectWithData:responsedData
                                                               options:NSJSONReadingMutableContainers
                                                                 error:&parseError];
                  
                  if (!parsedData || parseError) {
                      NSLog(@"Update User Info 操作解析内容失败，原因: %@", parseError);
                      
                      NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                      handler(FALSE, err, @"", nil);
                      
                      if (requestType == UpdateContactUserInfo) {
                          [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateContactUserInfoFailedNotification
                                                                              object:(NSError *)err];
                          [self.opDelegate updateContactUserInfoFailedWithError:err];
                          
                      } else if(requestType == UpdateRelavantUserInfo) {
                          [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateRelavantUserInfoFailedNotification
                                                                              object:(NSError *)err];
                          [self.opDelegate updateRelavantUserInfoFailedWithError:err];
                      }
                      
                  } else {
                      
                      RequestResult result = (RequestResult)[parsedData[@"Result"] integerValue];
                      NSArray *usersData = nil;
                      NSError *err;
                      
                      NSMutableArray *updatedData = [NSMutableArray array];
                      
                      switch (result) {
                          case RequestSuccessful:
                              usersData = parsedData[@"Users"];
                              
                              if(usersData.count > 0) {
                                  for(NSDictionary *user in usersData) {
                                      WISUser *newUserInfo = [[WISUser alloc] initWithUserName:user[@"UserName"]
                                                                                          name:user[@"Name"]
                                                                               telephoneNumber:user[@"Telephone"]
                                                                               cellPhoneNumber:user[@"MobilePhone"]
                                                                                      roleCode:user[@"RoleCode"]
                                                                                      roleName:user[@"RoleName"]
                                                                                 andImagesInfo:[NSMutableDictionary dictionary]];
                                      
                                      
                                      if(![self.users valueForKey:[NSString stringWithFormat:@"%@", user[@"UserName"]]])
                                          [self.users setValue:newUserInfo forKey:[NSString stringWithFormat:@"%@", user[@"UserName"]]];
                                      
                                      [updatedData addObject:newUserInfo];
                                  }
                              }
                              
                              if (requestType == UpdateContactUserInfo) {
                                  [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateContactUserInfoSucceededNotification
                                                                                      object:updatedData];
                                  [self.opDelegate updateContactUserInfoSucceeded];
                                  
                              } else if(requestType == UpdateRelavantUserInfo) {
                                  [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateContactUserInfoSucceededNotification
                                                                                      object:updatedData];
                                  [self.opDelegate updateRelavantUserInfoSucceeded];
                              }
                              
                              handler(YES, nil, NSStringFromClass([updatedData class]), updatedData);
                              break;
                              
                          case RequestFailed:
                              err = [self produceErrorObjectWithWISErrorCode:ErrorCodeInvalidOperation andCallbackError:nil];
                              handler(FALSE, err, @"", nil);
                              
                              if (requestType == UpdateContactUserInfo) {
                                  [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateContactUserInfoFailedNotification object:(NSError *)err];
                                  [self.opDelegate updateContactUserInfoFailedWithError:err];
                                  
                              } else if(requestType == UpdateRelavantUserInfo) {
                                  [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateRelavantUserInfoFailedNotification object:(NSError *)err];
                                  [self.opDelegate updateRelavantUserInfoFailedWithError:err];
                              }
                              break;
                              
                          default:
                              break;
                      }
                  }
              }
         }];
    }
}



#pragma mark - Update Maintenance Task Information
/// Update Maintenance Task Brief Information Operation And Response Method
- (void) updateMaintenanceTaskBriefInfoWithTaskTypeID:(MaintenanceTaskType)taskTypeID
                                  completionHandler:(WISMaintenanceTaskUpdateInfoHandler)handler {

    NSDictionary * updateParams = nil;
    
    if ([self.currentUser.userName isEqual: @""] || self.currentUser.userName == nil
        || [self.networkRequestToken isEqual: @""] || self.networkRequestToken == nil) {
        
        NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeNoCurrentUserInfo andCallbackError:nil];
        handler(FALSE, err, @"", nil);
        
        [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskBriefInfoFailedNotification object:(NSError *)err];
        [self.opDelegate updateMaintenanceTasksBriefInfoFailedWithError:err];
        
        return;
        
    } else {
        
        updateParams = [NSDictionary dictionaryWithObjectsAndKeys:self.currentUser.userName, @"UserName",
                        self.networkRequestToken, @"PassWord", nil];
        
        [self.networkService dataRequestWithRequestType:UpdateMaintenanceTaskBriefInfo
                                                 params:updateParams
                                          andUriSetting:[NSArray arrayWithObjects:[NSString stringWithFormat:@"%ld", (long)taskTypeID], nil]
         completionHandler:^(RequestType requestType, NSData *responsedData, NSError *error) {
              if (!responsedData) {
                  NSLog(@"Update MaintenanceTask Brief Info 请求异常，原因: %@", @"返回的数据为空");
                  
                  NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData andCallbackError:error];
                  handler(FALSE, err, @"", nil);
                  
                  [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskBriefInfoFailedNotification object:(NSError *)err];
                  [self.opDelegate updateMaintenanceTasksBriefInfoFailedWithError:err];
                  
              } else {
                  
                  NSError *parseError;
                  NSDictionary *parsedData = nil;
                  
                  parsedData = [NSJSONSerialization JSONObjectWithData:responsedData
                                                               options:NSJSONReadingMutableContainers
                                                                 error:&parseError];
                  
                  if (!parsedData || parseError) {
                      NSLog(@"Update MaintenanceTask Brief Info 操作解析内容失败，原因: %@", parseError);
                      
                      NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                      handler(FALSE, err, @"", nil);
                      
                      [[NSNotificationCenter defaultCenter]
                       postNotificationName:WISUpdateMaintenanceTaskBriefInfoFailedNotification
                       object:(NSError *)err];
                      
                      [self.opDelegate updateMaintenanceTasksBriefInfoFailedWithError:err];
                      
                  } else {
                      
                      RequestResult result = (RequestResult)[parsedData[@"Result"] integerValue];
                      NSArray *tasks = nil;
                      NSString *taskID = nil;
                      NSInteger taskCount = 0;
                      
                      NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                      [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                      
                      NSError *err;
                      
                      NSMutableArray *updatedData = [NSMutableArray array];
                      
                      switch (result) {
                          case RequestSuccessful:
                              taskCount = [parsedData[@"Count"] integerValue];
                              
                              if(taskCount <= 0) {
                                  // do nothing
                              } else {
                                  
                                  //
                                  [self.maintenanceTasks removeAllObjects];
                                  
                                  tasks = parsedData[@"Tasks"];
                                  for(NSDictionary *task in tasks) {
                                      
                                      taskID = [NSString stringWithFormat:@"%@", task[@"TaskId"]];
                                      
                                      WISMaintenanceTask *maintenanceTask = [[WISMaintenanceTask alloc] init];
                                      
                                      maintenanceTask.taskID = taskID;
                                      maintenanceTask.taskName = (NSString *)task[@"TaskName"];
                                      maintenanceTask.taskDescription = (NSString *)task[@"Description"];
                                      maintenanceTask.createdDateTime = [dateFormatter dateFromString:task[@"CreateTime"]];
                                      maintenanceTask.state = (NSString *)task[@"Status"];
                                      maintenanceTask.taskType = taskTypeID;

                                      [self.maintenanceTasks setValue:maintenanceTask forKey:taskID];
                                      [updatedData addObject:maintenanceTask];
                                  }
                              }
                              
                              [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskBriefInfoSucceededNotification
                                                                                  object:updatedData];
                              
                              [self.opDelegate updateMaintenanceTasksBriefInfoSucceeded];
                              handler(YES, nil, NSStringFromClass([updatedData class]), updatedData);
                              break;
                              
                          case RequestFailed:
                              err = [self produceErrorObjectWithWISErrorCode:ErrorCodeInvalidOperation andCallbackError:nil];
                              handler(FALSE, err, @"", nil);
                              
                              [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskBriefInfoFailedNotification
                                                                                  object:(NSError *)err];
                              
                              [self.opDelegate updateMaintenanceTasksBriefInfoFailedWithError:err];
                              break;
                              
                          default:
                              break;
                      }
                  }
              }
         }];
    }
}


/// Update Maintenance Task detail Information Operation And Response Method
- (void) updateMaintenanceTaskDetailInfoWithTaskID:(NSString *)taskID
                                 completionHandler:(WISMaintenanceTaskUpdateInfoHandler)handler {
    
    NSDictionary * updateParams = nil;
    
    if ([self.currentUser.userName isEqual: @""] || self.currentUser.userName == nil
        || [self.networkRequestToken isEqual: @""] || self.networkRequestToken == nil) {
        
        NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeNoCurrentUserInfo andCallbackError:nil];
        handler(FALSE, err, @"", nil);
        
        [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskDetailInfoFailedNotification object:(NSError *)err];
        [self.opDelegate updateMaintenanceTasksDetailInfoFailedWithError:err];
        
        return;
        
    } else {
        
        updateParams = [NSDictionary dictionaryWithObjectsAndKeys:self.currentUser.userName, @"UserName",
                        self.networkRequestToken, @"PassWord", nil];
        
        [self.networkService dataRequestWithRequestType:UpdateMaintenanceTaskDetailInfo
                                                 params:updateParams
                                          andUriSetting:[NSArray arrayWithObjects:taskID, nil]
         completionHandler:^(RequestType requestType, NSData *responsedData, NSError *networkError) {
              
              if (!responsedData) {
                  NSLog(@"Update maintenance task detail info 请求异常，原因: %@", @"返回的数据为空");
                  
                  NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData andCallbackError:networkError];
                  handler(FALSE, err, @"", nil);
                  
                  [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskDetailInfoFailedNotification
                                                                      object:(NSError *)err];
                  [self.opDelegate updateMaintenanceTasksDetailInfoFailedWithError:err];
                  
              } else {
                  
                  NSError *parseError;
                  NSDictionary *parsedData = nil;
                  
                  parsedData = [NSJSONSerialization JSONObjectWithData:responsedData
                                                               options:NSJSONReadingMutableContainers
                                                                 error:&parseError];
                  
                  if (!parsedData || parseError) {
                      NSLog(@"Update maintenance task detail info 操作解析内容失败，原因: %@", parseError);
                      
                      NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                      handler(FALSE, err, @"", nil);
                      
                      [[NSNotificationCenter defaultCenter]
                       postNotificationName:WISUpdateMaintenanceTaskDetailInfoFailedNotification
                       object:(NSError *)err];
                      
                      [self.opDelegate updateMaintenanceTasksDetailInfoFailedWithError:err];
                      
                  } else {
                      
                      RequestResult result = (RequestResult)[parsedData[@"Result"] integerValue];
                      NSDictionary *taskDetail = nil;
                      NSMutableArray *operations = nil;
                      
                      WISMaintenanceTask *newMaintenanceTask = nil;
                      
                      WISUser *taskCreator = [[WISUser alloc] init];
                      WISUser *taskPersonInCharge = [[WISUser alloc] init];
                      
                      NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
                      [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
                      
                      NSMutableDictionary *validOperations = [NSMutableDictionary dictionary];
                      NSError *err;
                      
                      switch (result) {
                          /// 请求成功
                          case RequestSuccessful:
                              if (![_maintenanceTasks valueForKey:taskID]) {
                                  newMaintenanceTask = [[WISMaintenanceTask alloc] init];
                                  newMaintenanceTask.taskID = taskID;
                                  [_maintenanceTasks addEntriesFromDictionary:[NSDictionary dictionaryWithObject:newMaintenanceTask forKey:taskID]];
                              }
                              
                              // update valid operations
                              operations = parsedData[@"Privileges"];
                              
                              if(!operations || ((NSNull *)operations == [NSNull null])) {
                                  _maintenanceTasks[taskID].validOperations =
                                  [NSDictionary dictionaryWithObjectsAndKeys:@"空操作", [NSString stringWithFormat:@"%ld", (long)NULLOperation], nil];
                                  
                              } else {
                                  for (NSDictionary *operation in operations) {
                                      [validOperations addEntriesFromDictionary:[NSDictionary
                                                                                 dictionaryWithObject:(NSString *)operation[@"PrivilegeName"]
                                                                                 forKey:[NSString stringWithFormat:@"%@", operation[@"PrivilegeID"]]]];
                                  }
                                  _maintenanceTasks[taskID].validOperations = [NSDictionary dictionaryWithDictionary:validOperations];
                              }
                              
                              taskDetail = parsedData[@"Detail"];
                              if(!((NSNull *)taskDetail == [NSNull null])) {
                                  
                                  // update creator and person-in-charge
                                  NSDictionary *creator = (NSDictionary *)taskDetail[@"Creator"];
                                  if (creator && !((NSNull *)creator == [NSNull null])) {
                                      taskCreator.userName = (NSString *)creator[@"UserName"];
                                      taskCreator.fullName = (NSString *)creator[@"Name"];
                                      taskCreator.roleCode = (NSString *)creator[@"RoleCode"];
                                      taskCreator.roleName = (NSString *)creator[@"RoleName"];
                                      taskCreator.cellPhoneNumber = (NSString *)creator[@"MobilePhone"];
                                      taskCreator.telephoneNumber = (NSString *)creator[@"Telephone"];
                                      _maintenanceTasks[taskID].creator = taskCreator;
                                      
                                      if (![self.users valueForKey:taskCreator.userName])
                                          [self.users setValue:taskCreator forKey:taskCreator.userName];
                                  } else {
                                      // do nothing, because WISMaintenanceTask initializer has done the initial job.
                                      // _maintenanceTasks[taskID].creator = nil;
                                  }
                                  
                                  NSDictionary *personInCharge = (NSDictionary *)taskDetail[@"Manager"];
                                  
                                  if (personInCharge && !((NSNull *)personInCharge == [NSNull null])) {
                                      taskPersonInCharge.userName = (NSString *)personInCharge[@"UserName"];
                                      taskPersonInCharge.fullName = (NSString *)personInCharge[@"Name"];
                                      taskPersonInCharge.roleCode = (NSString *)personInCharge[@"RoleCode"];
                                      taskPersonInCharge.roleName = (NSString *)personInCharge[@"RoleName"];
                                      taskPersonInCharge.cellPhoneNumber = (NSString *)personInCharge[@"MobilePhone"];
                                      taskPersonInCharge.telephoneNumber = (NSString *)personInCharge[@"Telephone"];
                                      _maintenanceTasks[taskID].personInCharge = taskPersonInCharge;
                                  
                                      if (![self.users valueForKey:taskPersonInCharge.userName])
                                          [self.users setValue:taskPersonInCharge forKey:taskPersonInCharge.userName];
                                  } else {
                                      // do nothing, because WISMaintenanceTask initializer has done the initial job.
                                      // _maintenanceTasks[taskID].personInCharge = nil;
                                  }
                                  
                                  // update description
                                  _maintenanceTasks[taskID].taskApplicationContent = (NSString *)taskDetail[@"Description"];
                                  
                                  // process segment
                                  _maintenanceTasks[taskID].processSegmentName = (NSString *)taskDetail[@"FaultArea"];
                                  
                                  // task name
                                  _maintenanceTasks[taskID].taskName = (NSString *)taskDetail[@"TaskName"];
                                  
                                  // task status
                                  _maintenanceTasks[taskID].state = (NSString *)taskDetail[@"TaskStatus"];
                                  
                                  //images info - MaintenanceTask
                                  NSArray *imagesURL = (NSArray *)taskDetail[@"FileURL"];
                                  if (imagesURL && !((NSNull *)imagesURL == [NSNull null])) {
                                      for (NSString *url in imagesURL) {
                                          WISFileInfo *imageInfo = [self produceFileInfoWithFileRemoteURL:url];
                                          
                                          if (![_maintenanceTasks[taskID].imagesInfo valueForKey:imageInfo.fileName]) {
                                              [_maintenanceTasks[taskID].imagesInfo setValue:imageInfo forKey:imageInfo.fileName];
                                          }
                                      }
                                      
                                  } else {
                                      // ** test **
                                      NSString *fileFullName = @"E:\\FTP\\MM\\taskID-213-iOS-E5EF893D-CB29-434A-AAC6-70E882F999CC.20160321160616.png";
                                      NSArray *fileFullNameComponent = [fileFullName componentsSeparatedByString:@"\\"];
                                                                        
                                      NSString *fileNameTest = [fileFullNameComponent objectAtIndex:(fileFullNameComponent.count - 1)];
                                      NSString *ex = [fileNameTest pathExtension];
                                      NSString *fileNamePure = [[fileNameTest componentsSeparatedByString:@"."] objectAtIndex:0];
                                      
                                      fileNamePure = fileNamePure;
                                      
                                      // do nothing, because WISMaintenanceTask initializer has done the initializing job.
                                  }
                                  
                                  // maintenance plan
                                  NSDictionary *planDic = (NSDictionary *)taskDetail[@"PlanInformation"];
                                  if (planDic && !((NSNull *)planDic == [NSNull null])) {
                                      WISMaintenancePlan *plan = [[WISMaintenancePlan alloc] init];
                                      
                                      plan.planDescription = planDic[@"Description"];
                                      
                                      if (!planDic[@"EstimatedTime"]) {
                                          plan.estimatedEndingTime = [dateFormatter dateFromString:(NSString *)planDic[@"EstimatedTime"]];
                                      } else {
                                          // do nothing, because WISMaintenanceTask initializer has done the initial job.
                                          // plan.estimatedEndingTime = nil;
                                      }
                                      
                                      NSMutableArray<NSDictionary *> *participants = nil;
                                      if ((participants = planDic[@"Participants"])) {
                                          if (participants.count > 0)
                                              for (NSDictionary *participant in participants) {
                                                  WISUser *planParticipant = [[WISUser alloc] init];
                                                  planParticipant.userName = (NSString *)participant[@"UserName"];
                                                  planParticipant.fullName = (NSString *)participant[@"Name"];
                                                  planParticipant.roleCode = (NSString *)participant[@"RoleCode"];
                                                  planParticipant.roleName = (NSString *)participant[@"RoleName"];
                                                  planParticipant.cellPhoneNumber = (NSString *)participant[@"MobilePhone"];
                                                  planParticipant.telephoneNumber = (NSString *)participant[@"TelePhone"];
                                                  
                                                  [plan.participants addObject:planParticipant];
                                                  
                                                  if (![self.users valueForKey:planParticipant.userName])
                                                      [self.users setValue:planParticipant forKey:planParticipant.userName];
                                              }
                                      }
                                      
                                      //images info - MaintenanceTask plan
                                      NSArray *imagesURL = (NSArray *)planDic[@"FileURL"];
                                      if (imagesURL && !((NSNull *)imagesURL == [NSNull null])) {
                                          for (NSString *url in imagesURL) {
                                              WISFileInfo *imageInfo = [self produceFileInfoWithFileRemoteURL:url];
                                              
                                              if (![plan.imagesInfo valueForKey:imageInfo.fileName]) {
                                                  [plan.imagesInfo setValue:imageInfo forKey:imageInfo.fileName];
                                              }
                                          }
                                          
                                      } else {
                                          // do nothing, because WISMaintenanceTask initializer has done the initializing job.
                                      }
                                      
                                      _maintenanceTasks[taskID].maintenancePlan = plan;
                                      
                                  } else {
                                      // do nothing, because WISMaintenanceTask initializer has done the initializing job.
                                  }
                              }
                              
                              [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskDetailInfoSucceededNotification
                                                                                  object:[_maintenanceTasks[taskID] copy]];
                              
                              [self.opDelegate updateMaintenanceTasksDetailInfoSucceeded];
                              handler(YES, nil, NSStringFromClass([_maintenanceTasks[taskID] class]), [_maintenanceTasks[taskID] copy]);
                              break;
                              
                          /// 请求失败
                          case RequestFailed:
                              err = [self produceErrorObjectWithWISErrorCode:ErrorCodeInvalidOperation andCallbackError:nil];
                              handler(FALSE, err, @"", nil);
                              
                              [[NSNotificationCenter defaultCenter] postNotificationName:WISUpdateMaintenanceTaskDetailInfoFailedNotification
                                                                                  object:(NSError *)err];
                              
                              [self.opDelegate updateMaintenanceTasksDetailInfoFailedWithError:err];
                              break;
                              
                          default:
                              break;
                      }
                  }
              }
         }];
    }
}


- (void) applyNewMaintenanceTaskWithApplicationContent:(NSString *)applicationContent
                                      processSegmentID:(NSString *)processSegmentID
                                  applicationImageInfo:(NSDictionary<NSString *, WISFileInfo *> *)applicationImagesInfo
                                      completionHandler:(WISMaintenanceTaskOperationHandler)handler {
    [self maintenanceTaskOperationWithTaskID:@""
                                      remark:@""
                               operationType:SubmitApply
                            taskReceiverName:@""
                          applicationContent:applicationContent
                            processSegmentID:[processSegmentID integerValue]
                        applicationImageInfo:applicationImagesInfo
          maintenancePlanEstimatedEndingTime:nil
                  maintenancePlanDescription:@""
                 maintenancePlanParticipants:nil
                               taskImageInfo:nil
                                  taskRating:nil
                        andCompletionHandler:handler];
}


- (void) maintenanceTaskOperationWithTaskID:(NSString *) taskID
                                     remark:(NSString *) remark
                              operationType:(MaintenanceTaskOperationType) operationType
                           taskReceiverName:(NSString *) taskReceiverName /*转单时用. 非转单时填@""*/
         maintenancePlanEstimatedEndingTime:(NSDate *) maintenancePlanEstimatedEndingTime
                 maintenancePlanDescription:(NSString *) maintenancePlanDescription
                maintenancePlanParticipants:(NSArray <WISUser *> *) maintenancePlanParticipants
                              taskImageInfo:(NSDictionary<NSString *, WISFileInfo *> *)taskImagesInfo
                                 taskRating:(WISMaintenanceTaskRating *) taskRating
                       andCompletionHandler:(WISMaintenanceTaskOperationHandler) handler {
    
    [self maintenanceTaskOperationWithTaskID:taskID
                                      remark:remark
                               operationType:operationType
                            taskReceiverName:taskReceiverName
                          applicationContent:@""
                            processSegmentID:0
                        applicationImageInfo:nil
          maintenancePlanEstimatedEndingTime:maintenancePlanEstimatedEndingTime
                  maintenancePlanDescription:maintenancePlanDescription
             maintenancePlanParticipants:maintenancePlanParticipants
                               taskImageInfo:taskImagesInfo
                                  taskRating:taskRating
                        andCompletionHandler:handler];
}


#pragma mark - Image Operations for APP interface

- (void) storeImageOfUserWithUserName:(NSString *)userName
                               images:(NSDictionary<NSString *,UIImage *> *)images
              uploadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                    completionHandler:(WISSystemFileOperationHandler)handler {
    [self storeImageWithImages:images
     /// PROGRESS
     uploadProgressIndicator:progress
     /// COMPLETION HANDLER
     completionHandler:^(BOOL completedWithNoError, NSError *error, NSString *classNameOfDataAsString, id data) {
         if (completedWithNoError) {
             NSArray<WISFileInfo *> *imagesInfo = (NSArray<WISFileInfo *> *)data;
             
             if (imagesInfo.count > 0) {
                 if (userName == _currentUser.userName) {
                     for (WISFileInfo *info in imagesInfo) {
                         if (![self.currentUser.imagesInfo valueForKey:info.fileName]) {
                             [self.currentUser.imagesInfo setValue:info forKey:info.fileName];
                         }
                     }
                 } else {
                     for (WISFileInfo *info in imagesInfo) {
                         if (![self.users[userName].imagesInfo valueForKey:info.fileName]) {
                             [self.users[userName].imagesInfo setValue:info forKey:info.fileName];
                         }
                     }
                 }
             }
             handler(TRUE, nil, NSStringFromClass([imagesInfo class]), imagesInfo);
             
         } else {
             
             handler(FALSE, error, @"", nil);
         }
     }];
}


- (void) obtainImageOfUserWithUserName:(NSString *)userName
                            imagesInfo:(NSDictionary<NSString *,WISFileInfo *> *)imagesInfo
             downloadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                     completionHandler:(WISSystemFileOperationHandler)handler {
    [self obtainImageWithImagesInfo:imagesInfo
     /// PROGRESS
          downloadProgressIndicator:progress
     /// COMPLETION HANDLER
                  completionHandler:handler];
}



- (void) storeImageOfMaintenanceTaskWithTaskID:(NSString *)taskID
                                        images:(NSDictionary<NSString *,UIImage *> *)images
                       uploadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                             completionHandler:(WISSystemFileOperationHandler)handler {
    [self storeImageWithImages:images
     /// PROGRESS
     uploadProgressIndicator:progress
     /// COMPLETION HANDLER
     completionHandler:^(BOOL completedWithNoError, NSError *error, NSString *classNameOfDataAsString, id data) {
         if (completedWithNoError) {
             NSArray<WISFileInfo *> *imagesInfo = (NSArray<WISFileInfo *> *)data;
             
             if (imagesInfo.count > 0) {
                 for (WISFileInfo *info in imagesInfo) {
                     if (taskID && ![taskID isEqualToString:@""]) {
                         if (![self.maintenanceTasks[taskID].imagesInfo valueForKey:info.fileName]) {
                             [self.maintenanceTasks[taskID].imagesInfo setValue:info forKey:info.fileName];
                         }
                     }                     
                 }
             }
             handler(TRUE, nil, NSStringFromClass([imagesInfo class]), imagesInfo);
             
         } else {
             
             handler(FALSE, error, @"", nil);
         }
     }];
}


- (void) obtainImageOfMaintenanceTaskWithTaskID:(NSString *)taskID
                                     imagesInfo:(NSDictionary<NSString *,WISFileInfo *> *)imagesInfo
                      downloadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                              completionHandler:(WISSystemFileOperationHandler)handler {
    [self obtainImageWithImagesInfo:imagesInfo
     /// PROGRESS
     downloadProgressIndicator:progress
     /// COMPLETION HANDLER
     completionHandler:handler];
}


#pragma mark - File/Data Transmission and Operation

// 保存图片 (本地／远端服务器)
- (void) storeImageWithImages:(NSDictionary<NSString *, UIImage *> *)images
      uploadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
            completionHandler:(WISSystemFileOperationHandler)handler {
    if (images.count > 0) {
        [[[WISFileStoreManager defaultManager]imageStore]setImages:images];
        
        [self uploadImageWithImages:images
         /// PROGRESS
         progressIndicator:^(NSProgress *transmissionProgress) {
             progress(transmissionProgress);
             
         }
         /// COMPLETION HANDLER
         completionHandler:^(BOOL completedWithNoError, NSError *error, NSString *classNameOfReceivedDataAsString, id receivedData) {
             handler(completedWithNoError, error, classNameOfReceivedDataAsString, receivedData);
         }];
    }
}


// 获取图片 (本地／远端服务器)
- (void) obtainImageWithImagesInfo:(NSDictionary<NSString *, WISFileInfo *> *)imagesInfo
         downloadProgressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                 completionHandler:(WISSystemFileOperationHandler)handler {
    
    NSArray<NSString *> *requiredImagesName = [imagesInfo allKeys];
    NSArray<NSString *> *imagesNameNotContainedInLocalStore =
        [[[WISFileStoreManager defaultManager] imageStore] findImagesNameNotContainedInStoreFrom:requiredImagesName];
    
    if (imagesNameNotContainedInLocalStore.count <= 0) {
        NSDictionary<NSString *, UIImage *> *requiredImages = nil;
        requiredImages = [[[WISFileStoreManager defaultManager]imageStore]imagesForImagesName:requiredImagesName];
        
        progress(nil);
        handler(YES, nil, NSStringFromClass([requiredImages class]), requiredImages);
    
    } else {
        
        NSMutableArray<NSString *> *requiredImagesRemoteLocation = [NSMutableArray array];
        
        for (NSString *imageName in imagesNameNotContainedInLocalStore) {
            [requiredImagesRemoteLocation addObject:imagesInfo[imageName].fileRemoteLocation];
        }
        
        [self downloadImageWithImageLocations:requiredImagesRemoteLocation
         /// PROGRESS
         //progressIndicator:^(NSProgress *transmissionProgress) {
         progressIndicator:progress
         
         /// COMPLETION HANDLER
         completionHandler:^(BOOL completedWithNoError, NSError *error, NSString *classNameOfReceivedDataAsString, id receivedData) {
             NSDictionary<NSString *, UIImage *> *requiredImages = nil;
             if (receivedData) {
                 [[[WISFileStoreManager defaultManager]imageStore]setImages:(NSDictionary<NSString *, UIImage *> *)receivedData];
             }
             
             requiredImages = [[[WISFileStoreManager defaultManager]imageStore]imagesForImagesName:requiredImagesName];
             
             handler(completedWithNoError, error, NSStringFromClass([requiredImages class]), requiredImages);
         }];
    }
}


-  (void) clearCacheOfImages {
    [[[WISFileStoreManager defaultManager]imageStore] clearCacheInMemory];
    [[[WISFileStoreManager defaultManager]imageStore]clearCacheOnDeviceStorage];
}


/// 上传图片
- (void) uploadImageWithImages:(NSDictionary<NSString *, UIImage *> *)images
             progressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
             completionHandler:(WISSystemDataTransmissionHandler)handler {
    
    NSMutableData *uploadData = [NSMutableData data];
    // data header
    NSData *dataHeader = nil;
    
    NSData *dataSummary = nil;
    NSMutableArray *dataSummaryAsArray = [NSMutableArray array];
    
    NSMutableData *dataBody = [NSMutableData data];
    
    if (images.count <=0) {
        NSLog(@"No image submited for uploading! Pls check the code!");
        return;
    } else {
        //
        // ** Construct data body
        //
        NSData *imageData = nil;
        NSInteger offset = 0;
        
        NSDictionary *fileDescriptionInDataSummary = nil;
        NSArray *imageNames = [images allKeys];
        
        for (int i = 0; i < imageNames.count; i++) {
            // imageData = UIImageJPEGRepresentation(images[i], 1.0f);
            imageData = UIImagePNGRepresentation(images[imageNames[i]]);
            
            [dataBody appendData:imageData];
            
            fileDescriptionInDataSummary = [NSDictionary dictionaryWithObjectsAndKeys:
                                            @"png", @"FileType",
                                            imageNames[i], @"FileName",
                                            [NSNumber numberWithInteger:offset], @"Offset",
                                            [NSNumber numberWithUnsignedInteger: imageData.length], @"Length", nil];
            
            [dataSummaryAsArray addObject:fileDescriptionInDataSummary];
            
            offset += imageData.length;
        }
        //
        // ** Construct data summary
        //
        NSError *dataSummaryConvertJSONError = nil;
        
        dataSummary = [NSJSONSerialization dataWithJSONObject:dataSummaryAsArray
                                                      options:NSJSONWritingPrettyPrinted
                                                        error:&dataSummaryConvertJSONError];
        
        NSString *dataSummaryAsString = [[NSString alloc] initWithData:dataSummary encoding:NSUTF8StringEncoding];
        
        if (dataSummaryConvertJSONError){
            // do nothing at the moment
        }
        //
        // ** Construct data summary
        //
        int64_t dataHeaderAsInt = (int64_t)dataSummary.length;
        
        dataHeader = [NSData dataWithBytes:&dataHeaderAsInt length:8];
        
        // stick together
        [uploadData appendData:dataHeader];
        [uploadData appendData:dataSummary];
        [uploadData appendData:dataBody];
        
        [self.networkService uploadRequestWithFileContentType:ImageOfMaintenanceTask
                                                       params:nil
                                                   uriSetting:nil
                                                andUploadData:uploadData
         // PROGRESS
         progressIndicator:^(NSProgress * _Nonnull transmissionProgress) {
             progress(transmissionProgress);
         }
         // COMPLETION HANDLER
         completionHandler:^(NSData *responsedData, NSError *networkError) {
             if (networkError) {
                 NSLog(@"Upload image of maintenance task 网络传输异常，原因: %@", networkError);
                 
                 NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeNetworkTransmission andCallbackError:networkError];
                 handler(FALSE, err, @"", nil);
                 
                 [[NSNotificationCenter defaultCenter] postNotificationName:WISUploadImagesFailedNotification object:(NSError *)err];
                 [self.opDelegate uploadImagesFailedWithError:err];
                 
             } else {
                 if (!responsedData) {
                     NSLog(@"Upload image of maintenance task 请求异常，原因: %@", @"返回的数据为空");
                     
                     NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData andCallbackError:nil];
                     handler(FALSE, err, @"", nil);
                     
                     [[NSNotificationCenter defaultCenter] postNotificationName:WISUploadImagesFailedNotification object:(NSError *)err];
                     [self.opDelegate uploadImagesFailedWithError:err];
                     
                 } else {
                     
                     NSError *parseError;
                     NSDictionary *parsedData = nil;
                     
                     parsedData = [NSJSONSerialization JSONObjectWithData:responsedData
                                                                  options:NSJSONReadingMutableContainers
                                                                    error:&parseError];
                     
                     if (!parsedData || parseError) {
                         NSLog(@"Upload image of maintenance task 操作解析服务器返回参数失败，原因: %@", parseError);
                         
                         NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                         handler(FALSE, err, @"", nil);
                         
                         [[NSNotificationCenter defaultCenter]
                          postNotificationName:WISUploadImagesFailedNotification object:(NSError *)err];
                         
                         [self.opDelegate uploadImagesFailedWithError:err];
                         
                     } else {
                         
                         RequestResult result = (RequestResult)[parsedData[@"Result"] integerValue];
                         NSArray *fileInfos = nil;
                         NSError *err;
                         
                         // NSMutableDictionary *updatedData = [NSMutableDictionary dictionary];
                         NSMutableArray<WISFileInfo *> *currentImagesInfo = [NSMutableArray array];
                         WISFileInfo *imageInfo = nil;
                         
                         switch (result) {
                             case RequestSuccessful:
                                 fileInfos = parsedData[@"FileInformation"];
                                 
                                 if (!fileInfos || (NSNull *)fileInfos == [NSNull null]) {
                                     
                                 } else {
                                     if(fileInfos.count > 0) {
                                         for(NSDictionary *fileInfo in fileInfos) {
                                             
                                             imageInfo = [[WISFileInfo alloc] init];
                                             imageInfo.fileName = [[[NSString stringWithString:fileInfo[@"FileName"]]componentsSeparatedByString:@"."] objectAtIndex:0];
                                             imageInfo.fileRemoteLocation = fileInfo[@"Url"];
                                             imageInfo.fileType = [imageInfo.fileRemoteLocation pathExtension];
                                             imageInfo.fileOnDeviceLocation = @"";
                                             
                                             [currentImagesInfo addObject:imageInfo];
                                             
                                             /// !!! 这一句要放到维保任务的图片上传程序里！！！
//                                             if (![self.maintenanceTasks[taskID].imagesInfo valueForKey:imageInfo.fileName]) {
//                                                 [self.maintenanceTasks[taskID].imagesInfo setValue:imageInfo forKey:imageInfo.fileName];
//                                             }
                                         }
                                     }
                                 }
                                 
                                 [[NSNotificationCenter defaultCenter]
                                  postNotificationName:WISUploadImagesSucceededNotification object:currentImagesInfo];
                                 
                                 [self.opDelegate uploadImagesSucceeded];
                                 handler(TRUE, nil, NSStringFromClass([currentImagesInfo class]), currentImagesInfo);
                                 break;
                                 
                             case RequestFailed:
                                 err = [self produceErrorObjectWithWISErrorCode:ErrorCodeInvalidOperation andCallbackError:nil];
                                 
                                 [[NSNotificationCenter defaultCenter]
                                  postNotificationName:WISUploadImagesFailedNotification
                                  object:(NSError *)err];
                                 
                                 [self.opDelegate uploadImagesFailedWithError:err];
                                 handler(FALSE, err, @"", nil);
                                 break;
                                 
                             default:
                                 break;
                         }
                     }
                 }
             }
         }];
    }
}


/// 下载图片
- (void) downloadImageWithImageLocations:(NSArray<NSString *> *)imagesRemoteLocation
                       progressIndicator:(WISSystemDataTransmissionProgressIndicator)progress
                       completionHandler:(WISSystemDataTransmissionHandler)handler {
   
    NSDictionary *downloadParams = [NSDictionary dictionaryWithObjectsAndKeys:imagesRemoteLocation, @"FileURL", nil];
    
    [self.networkService downloadRequestWithFileContentType:ImageOfMaintenanceTask params:downloadParams uriSetting:nil
     // PROGRESS
     progressIndicator:^(NSProgress *transmissionProgress) {
         progress(transmissionProgress);
         
     // COMPLETION HANDLER
     } completionHandler:^(NSData *responsedData, NSError *networkError) {
         if(networkError) {
             NSLog(@"Download image of maintenance task 网络传输异常，原因: %@", networkError);
             
             NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeNetworkTransmission andCallbackError:networkError];
             handler(FALSE, err, @"", nil);
             
             [[NSNotificationCenter defaultCenter] postNotificationName:WISDownloadImagesFailedNotification object:(NSError *)err];
             [self.opDelegate downloadImagesFailedWithError:err];
             
         } else {
             
             if ((!responsedData)||responsedData.length == 0) {
                 NSLog(@"Download image of maintenance task 请求异常，原因: %@", @"返回的数据为空");
                 
                 NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData andCallbackError:nil];
                 handler(FALSE, err, @"", nil);
                 
                 [[NSNotificationCenter defaultCenter] postNotificationName:WISDownloadImagesFailedNotification object:(NSError *)err];
                 [self.opDelegate downloadImagesFailedWithError:err];
                 
             } else {
                 
                 NSData *dataHeader = nil;
                 NSData *dataSummary = nil;

                 //
                 // ** Extract data header
                 //
                 NSRange rangeOfHeader = NSMakeRange(0, 8);
                 dataHeader = [responsedData subdataWithRange:rangeOfHeader];
                 
                 int64_t *headerAddress = (int64_t *)dataHeader.bytes;
                 int64_t lengthOfDataSummary = *headerAddress;
                 //
                 // ** Extract data summary
                 //
                 NSRange rangeOfSummary = NSMakeRange(8, lengthOfDataSummary);
                 dataSummary = [responsedData subdataWithRange:rangeOfSummary];
                 //
                 // ** Parse data summary
                 //
                 NSError *parseError;
                 NSArray *parsedData = nil;
                 
                 parsedData = [NSJSONSerialization JSONObjectWithData:dataSummary
                                                              options:NSJSONReadingMutableContainers
                                                                error:&parseError];
                 
                 if (!parsedData || parseError) {
                     NSLog(@"Download image of maintenance task 操作解析数据包内的文件信息参数失败，原因: %@", parseError);
                     
                     NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                     
                     [[NSNotificationCenter defaultCenter]
                      postNotificationName:WISDownloadImagesFailedNotification
                      object:(NSError *)err];
                     
                     [self.opDelegate downloadImagesFailedWithError:err];
                     
                     handler(FALSE, err, @"", nil);
                     
                 } else {
                     
                     NSInteger fileStartAddress = 8 + lengthOfDataSummary;
                     NSData *imageData = nil;
                     NSMutableDictionary<NSString *, UIImage *> *receivedImages = [NSMutableDictionary dictionary];
                     
                     NSInteger imageDataLength = 0;
                     NSInteger imageDataOffset = 0;
                     
                     if (parsedData.count <= 0) {
                         // do something later
                     } else {
                         
                         for (NSDictionary *fileStorageInfo in parsedData) {
                             imageDataLength = [fileStorageInfo[@"Length"] integerValue];
                             imageDataOffset = [fileStorageInfo[@"Offset"] integerValue];
                             
                             NSRange rangeOfimageData = NSMakeRange(fileStartAddress+imageDataOffset, imageDataLength);
                             imageData = [responsedData subdataWithRange:rangeOfimageData];
                             
                             UIImage *image = [UIImage imageWithData:imageData];
                             NSString *imageNameWithDate = [NSString stringWithFormat:@"%@", fileStorageInfo[@"FileName"]];
                             NSString *imageName = [[imageNameWithDate componentsSeparatedByString:@"."] objectAtIndex:0];
                             
                             if (![receivedImages valueForKey:imageName]) {
                                 [receivedImages setValue:image forKey:imageName];
                             }
                         }
                     }
                     
                     [[NSNotificationCenter defaultCenter] postNotificationName:WISDownloadImagesSucceededNotification object:receivedImages];
                     
                     [self.opDelegate downloadImagesSucceeded];
                     handler(TRUE, nil, NSStringFromClass([receivedImages class]), receivedImages);
                 }
             }
         }
     }];
}




#pragma mark - support method: producers

/// 对象内部使用, 用于进行各种操作请求的通用函数
- (void) maintenanceTaskOperationWithTaskID:(NSString *) taskID
                                     remark:(NSString *) remark
                              operationType:(MaintenanceTaskOperationType) operationType
                           taskReceiverName:(NSString *) taskReceiverName /*转单时用. 非转单时填@""*/
                         applicationContent:(NSString *) applicationContent
                           processSegmentID:(NSInteger) processSegmentID
                       applicationImageInfo:(NSDictionary<NSString *, WISFileInfo *> *)applicationImagesInfo
         maintenancePlanEstimatedEndingTime:(NSDate *) maintenancePlanEstimatedEndingTime
                 maintenancePlanDescription:(NSString *) maintenancePlanDescription
                maintenancePlanParticipants:(NSArray <WISUser *> *) maintenancePlanParticipants
                              taskImageInfo:(NSDictionary<NSString *, WISFileInfo *> *)taskImagesInfo
                                 taskRating:(WISMaintenanceTaskRating *) taskRating
                       andCompletionHandler:(WISMaintenanceTaskOperationHandler) handler{
    
    NSDictionary * operationParams = nil;
    
    if ([self.currentUser.userName isEqual: @""] || self.currentUser.userName == nil
        || [self.networkRequestToken isEqual: @""] || self.networkRequestToken == nil) {
        
        NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeNoCurrentUserInfo callbackError:nil
                                                         taskID:taskID
                                andMaintenanceTaskOperationType:operationType];
        handler(FALSE, err);
        
        [[NSNotificationCenter defaultCenter] postNotificationName:WISOperationOnMaintenanceTaskFailedNotification object:(NSError *)err];
        [self.opDelegate OperationOnMaintenanceTaskFailedWithError:err];
        
        return;
        
    } else {
        
        operationParams = [self produceMaintenanceTaskOperationParameterWithUserName:self.currentUser.userName
                                                                 networkRequestToken:self.networkRequestToken
                                                                              taskID:taskID
                                                                              remark:remark
                                                                       operationType:operationType
                                                                    taskReceiverName:taskReceiverName
                                                                  applicationContent:applicationContent
                                                                    processSegmentID:processSegmentID
                                                                applicationImageInfo:applicationImagesInfo
                                                  maintenancePlanEstimatedEndingTime:maintenancePlanEstimatedEndingTime
                                                          maintenancePlanDescription:maintenancePlanDescription
                                                         maintenancePlanParticipants:maintenancePlanParticipants
                                                                       taskImageInfo:taskImagesInfo
                                                                       andTaskRating:taskRating];
        
        [self.networkService dataRequestWithRequestType:SubmitCommand
                                                 params:operationParams
                                          andUriSetting:nil
         completionHandler:^(RequestType requestType, NSData *responsedData, NSError *networkError) {
              if (!responsedData) {
                  NSLog(@"Operation on maintenance task (taskID: %@) 请求异常，原因: %@", taskID, @"返回的数据为空");
                  
                  NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeResponsedNULLData callbackError:networkError
                                                                   taskID:taskID
                                          andMaintenanceTaskOperationType:operationType];
                  handler(FALSE, err);
                  
                  [[NSNotificationCenter defaultCenter] postNotificationName:WISOperationOnMaintenanceTaskFailedNotification object:(NSError *)err];
                  [self.opDelegate OperationOnMaintenanceTaskFailedWithError:err];
                  
              } else {
                  
                  NSError *parseError;
                  NSDictionary *parsedData = nil;
                  
                  parsedData = [NSJSONSerialization JSONObjectWithData:responsedData
                                                               options:NSJSONReadingMutableContainers
                                                                 error:&parseError];
                  
                  if (!parsedData || parseError) {
                      NSLog(@"Operation on maintenance task (taskID: %@) 解析返回内容失败，原因: %@", taskID, parseError);
                      
                      NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeIncorrectResponsedDataFormat andCallbackError:parseError];
                      handler(FALSE, err);
                      
                      [[NSNotificationCenter defaultCenter]
                       postNotificationName:WISOperationOnMaintenanceTaskFailedNotification
                       object:(NSError *)err];
                      
                      [self.opDelegate OperationOnMaintenanceTaskFailedWithError:err];
                      
                  } else {
                      
                      RequestResult result = (RequestResult)[parsedData[@"Result"] integerValue];
                      NSError *err;
                      
                      switch (result) {
                          case RequestSuccessful:
                              [[NSNotificationCenter defaultCenter]
                               postNotificationName:WISOperationOnMaintenanceTaskSucceededNotification object:self];
                              [self.opDelegate OperationOnMaintenanceTaskSucceeded];
                              
                              handler(YES, nil);
                              
                              break;
                              
                          case RequestFailed:
                              err = [self produceErrorObjectWithWISErrorCode:ErrorCodeInvalidOperation callbackError:nil taskID:taskID andMaintenanceTaskOperationType:operationType];
                              
                              [[NSNotificationCenter defaultCenter] postNotificationName:WISOperationOnMaintenanceTaskFailedNotification object:(NSError *)err];
                            
                              [self.opDelegate OperationOnMaintenanceTaskFailedWithError:err];
                              handler(FALSE, err);
                              break;
                              
                          default:
                              break;
                      }
                  }
                  
                  
//                  NSString *parsedData;
//                  
//                  parsedData = [[NSString alloc] initWithData:responsedData encoding:NSUTF8StringEncoding];
//                  
//                  BOOL operationSuccessful = [parsedData  isEqual: @"true"];
//                  
//                  if (operationSuccessful) {
//                      handler(YES, nil);
//                      
//                      [[NSNotificationCenter defaultCenter] postNotificationName:WISOperationOnMaintenanceTaskSucceededNotification object:self];
//                      
//                      [self.opDelegate OperationOnMaintenanceTaskSucceeded];
//                      
//                  } else {
//                      
//                      NSError *err = [self produceErrorObjectWithWISErrorCode:ErrorCodeInvalidOperation callbackError:nil
//                                                                       taskID:taskID
//                                              andMaintenanceTaskOperationType:operationType];
//                      handler(FALSE, err);
//                      
//                      [[NSNotificationCenter defaultCenter]
//                       postNotificationName:WISOperationOnMaintenanceTaskFailedNotification
//                       object:(NSError *)err];
//                      
//                      [self.opDelegate OperationOnMaintenanceTaskFailedWithError:err];
//                  }
              }
         }];
    }
}


/// 程序内部使用的支持性函数，用于操作请求过程网络参数的生成
- (NSDictionary *) produceMaintenanceTaskOperationParameterWithUserName:(NSString *) userName
                                                    networkRequestToken:(NSString *) requestToken
                                                                 taskID:(NSString *) taskID
                                                                 remark:(NSString *) remark
                                                          operationType:(MaintenanceTaskOperationType) operationType
                                                       taskReceiverName:(NSString *) taskReceiverName /*转单时用*/
                                                     applicationContent:(NSString *) applicationContent
                                                       processSegmentID:(NSInteger) processSegmentID
                                                   applicationImageInfo:(NSDictionary<NSString *, WISFileInfo *> *)applicationImagesInfo
                                     maintenancePlanEstimatedEndingTime:(NSDate *) maintenancePlanEstimatedEndingTime
                                             maintenancePlanDescription:(NSString *) maintenancePlanDescription
                                            maintenancePlanParticipants:(NSArray <WISUser *> *) maintenancePlanParticipants
                                                          taskImageInfo:(NSDictionary<NSString *, WISFileInfo *> *)taskImagesInfo
                                                          andTaskRating:(WISMaintenanceTaskRating *) taskRating {
    
    NSMutableDictionary *operationParam = [NSMutableDictionary dictionary];
    
    // userName and networkRequestToken
    [operationParam setValue:[NSDictionary dictionaryWithObjectsAndKeys:userName, @"UserName", requestToken, @"PassWord", nil]
                      forKey:@"User"];
    
    // taskID
    if (taskID == nil || [taskID isEqualToString:@""])
        [operationParam setValue:[NSNumber numberWithInteger:0] forKey:@"TaskID"];
    else
        [operationParam setValue:taskID forKey:@"TaskID"];

    // remark
    if (remark == nil || [remark isEqualToString:@""])
        [operationParam setValue:@"" forKey:@"Description"];
    else
        [operationParam setValue:remark forKey:@"Description"];
    
    // taskReceiverName
    if (taskReceiverName == nil || [taskReceiverName isEqualToString:@""])
        [operationParam setValue:[NSNull null] forKey:@"NextUserID"];
    else
        [operationParam setValue:taskReceiverName forKey:@"NextUserID"];
    
    // operationType
    [operationParam setValue:[NSNumber numberWithInteger:operationType] forKey:@"OperationID"];
    
    // ***** submit new maintenanceTask information *****
    if ((taskID == nil || [taskID isEqualToString:@""]) && operationType == SubmitApply) {
        NSString *tpAppContent = nil;
        NSInteger tpProcessSegmentID;
        NSMutableArray<NSString *> *tpApplicationImageLocations = [NSMutableArray array];
        
        if (applicationContent ==nil || [applicationContent isEqualToString:@""])
            tpAppContent = @"";
        else
            tpAppContent = applicationContent;
        
        if (processSegmentID == NSIntegerMin)
            tpProcessSegmentID = NSIntegerMin;
        else
            tpProcessSegmentID = processSegmentID;

        if (applicationImagesInfo && !((NSNull *)applicationImagesInfo == [NSNull null])) {
            if(applicationImagesInfo.count > 0) {
                for(WISFileInfo *imageInfo in applicationImagesInfo.allValues) {
                    [tpApplicationImageLocations addObject:imageInfo.fileRemoteLocation];
                }
            }
        }
        
        [operationParam setValue:[NSDictionary dictionaryWithObjectsAndKeys:tpAppContent, @"ApplyContent", [NSNumber numberWithInteger:tpProcessSegmentID], @"FaultAreaID", tpApplicationImageLocations, @"FileURL", nil]
                          forKey:@"Order"];
    } else {
        [operationParam setValue:[NSNull null] forKey:@"Order"];
    }
    
    
    // ***** maintenance plan information *****
    if (operationType != SubmitMaintenancePlan && operationType != Approve && operationType != Continue && operationType != Modify) {
        [operationParam setValue:[NSNull null] forKey:@"Plan"];
        
    } else {
    
        NSString *tpMaintenancePlanDescription = nil;
        NSDate *tpMaintenancePlanEstimatedEndingTime = nil;
        NSMutableArray<NSString *> *tpTaskImageLocations = [NSMutableArray array];
        NSMutableArray <NSDictionary *> *tpMaintenancePlanParticipants = [NSMutableArray array];
        
        // description
        if (maintenancePlanDescription == nil || [maintenancePlanDescription isEqualToString:@""])
            tpMaintenancePlanDescription = @"";
        else
            tpMaintenancePlanDescription = maintenancePlanDescription;
        // estimated ending time
        if (maintenancePlanEstimatedEndingTime == nil) {
            tpMaintenancePlanEstimatedEndingTime = [NSDate date];
            NSTimeZone *timeZone = [NSTimeZone systemTimeZone];
            NSInteger interval = [timeZone secondsFromGMTForDate: tpMaintenancePlanEstimatedEndingTime];
            tpMaintenancePlanEstimatedEndingTime = [tpMaintenancePlanEstimatedEndingTime dateByAddingTimeInterval:interval];
        } else
            tpMaintenancePlanEstimatedEndingTime = maintenancePlanEstimatedEndingTime;
        
        // imageLocations
        if (taskImagesInfo && !((NSNull *)taskImagesInfo == [NSNull null])) {
            if(taskImagesInfo.count > 0) {
                for(WISFileInfo *imageInfo in taskImagesInfo.allValues) {
                    [tpTaskImageLocations addObject:imageInfo.fileRemoteLocation];
                }
            }
        }
        
        // maintenancePlanParticipants
        if (maintenancePlanParticipants == nil) {
            // do nothing
        } else {
            if (maintenancePlanParticipants.count > 0) {
                for (WISUser *participant in maintenancePlanParticipants) {
                    [tpMaintenancePlanParticipants addObject:[NSDictionary dictionaryWithObjectsAndKeys:participant.userName, @"UserName", participant.fullName, @"Name", participant.roleCode, @"RoleCode", participant.roleName, @"RoleName", participant.cellPhoneNumber, @"MobilePhone", participant.telephoneNumber, @"Telephone", nil]];
                }
            }
        }
        
        // convert tpMaintenancePlanEstimatedEndingTime into NSString format
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
        NSString *maintenancePlanEstimatedEndingTimeAsString = [dateFormatter stringFromDate:tpMaintenancePlanEstimatedEndingTime];
        
        [operationParam setValue:[NSDictionary dictionaryWithObjectsAndKeys:tpMaintenancePlanDescription, @"Description",
                                  maintenancePlanEstimatedEndingTimeAsString, @"EstimatedTime",
                                  tpTaskImageLocations, @"FileURL",
                                  tpMaintenancePlanParticipants, @"Participants", nil]
                                  forKey:@"Plan"];
    }
    
    // ***** maintenance task rating *****
    if (taskRating !=nil) {
        [operationParam setValue:[NSDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithInteger:taskRating.totalScore], @"Score",
                                  [NSNumber numberWithInteger:taskRating.attitudeScore], @"AttitudeScore",
                                  [NSNumber numberWithInteger:taskRating.responseScore], @"ResponseScore",
                                  [NSNumber numberWithInteger:taskRating.qualityScore], @"QualityScore",
                                  taskRating.additionalRemark, @"Description", nil]
                          forKey:@"Remark"];
    } else {
        [operationParam setValue:[NSNull null] forKey:@"Remark"];
    }
    
    return operationParam;
}



/// 根据WISErrorCode, 生成相应的NSError.
- (NSError *) produceErrorObjectWithWISErrorCode:(WISErrorCode)code andCallbackError:(NSError *) callbackError {
    return [self produceErrorObjectWithWISErrorCode:code callbackError:callbackError taskID:@"" andMaintenanceTaskOperationType:NULLOperation];
}


/// 根据WISErrorCode, 生成相应的NSError. 本函数针对扩展了的NSError (参见NSError+WISExtension类), 增加taskID以及操作类型OperationType, 以便测试程序中, 能方便地找到错误源
- (NSError *) produceErrorObjectWithWISErrorCode:(WISErrorCode)code
                                   callbackError:(NSError *)callbackError
                                          taskID:(NSString *)taskID
                 andMaintenanceTaskOperationType:(MaintenanceTaskOperationType) operationType {
    
    NSMutableDictionary *userInfoAll = [NSMutableDictionary dictionary];
    
    if (callbackError && !((NSNull *)callbackError == [NSNull null])) {
        [userInfoAll addEntriesFromDictionary:callbackError.userInfo];
    }
    
    NSError *err = nil;
    NSDictionary *userInfoSelfDefined = nil;
    
    switch (code) {
            /// 函数参数错误
        case ErrorCodeWrongFuncParameters:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"传递给函数的参数有误", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"未填写用户名或密码", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"检查传递给函数的参数是否正确", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [NSError errorWithDomain:WISErrorDomain
                                      code:(NSInteger)ErrorCodeWrongFuncParameters
                                  userInfo:userInfoAll];
            break;
            
            /// 服务器返回的数据与预设值不一致，数据解析失败
        case ErrorCodeIncorrectResponsedDataFormat:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"返回的JSON数据解析失败", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"返回的数据格式有误，或数据不完整", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"检查数据库定义的值是否与程序设计一致", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [[NSError alloc] initWithDomain:WISErrorDomain
                                             code:(NSInteger)ErrorCodeIncorrectResponsedDataFormat
                                         userInfo:userInfoAll];
            break;
            
            /// 服务器返回的为nil，或网络连接异常
        case ErrorCodeResponsedNULLData:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"获得的返回数据为nil", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"HTTP请求参数错误，或网络连接异常", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"检查HTTP请求参数与网络连接是否异常", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [NSError errorWithDomain:WISErrorDomain
                                      code:(NSInteger)ErrorCodeResponsedNULLData
                                  userInfo:userInfoAll];
            break;
            
            /// 登录的用户不存在
        case ErrorCodeSignInUserNotExist:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"用户名不存在", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"登录的用户名不存在", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"请检查用户名", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [[NSError alloc] initWithDomain:WISErrorDomain
                                             code:(NSInteger)ErrorCodeSignInUserNotExist
                                         userInfo:userInfoAll];
            break;
            
            /// 登录密码错误
        case ErrorCodeSignInWrongPassword:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"密码错误", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"登录密码错误", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"请检查登录密码", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [[NSError alloc] initWithDomain:WISErrorDomain
                                             code:(NSInteger)ErrorCodeSignInWrongPassword
                                         userInfo:userInfoAll];
            break;
            
            /// 没有当前登录的用户信息
        case ErrorCodeNoCurrentUserInfo:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"无当前登录的用户信息", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"未正确登录", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"请重新登录", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [[NSError alloc] initWithDomain:WISErrorDomain
                                             code:(NSInteger)ErrorCodeNoCurrentUserInfo
                                         userInfo:userInfoAll];
            break;
            
            /// 操作非法
        case ErrorCodeInvalidOperation:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"操作失败", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"操作参数有误", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"请检查该操作的参数", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [[NSError alloc] initWithDomain:WISErrorDomain
                                             code:(NSInteger)ErrorCodeInvalidOperation
                                         userInfo:userInfoAll];
            break;
            
            /// 网络传输错误
        case ErrorCodeNetworkTransmission:
            userInfoSelfDefined =
                        @{NSLocalizedDescriptionKey:NSLocalizedString(@"网络传输错误", nil),
                         NSLocalizedFailureReasonErrorKey:NSLocalizedString(@"网络参数有误，或网络连接异常", nil),
                         NSLocalizedRecoverySuggestionErrorKey:NSLocalizedString(@"请检查程序中设置的网络参数设置是否与服务器端的定义一致，以及网络连接是否异常", nil),
                         ErrorTaskIDKey:taskID,
                         ErrorOperationTypeKey:[NSNumber numberWithInteger:operationType]};
            
            [userInfoAll addEntriesFromDictionary:userInfoSelfDefined];
            err = [[NSError alloc] initWithDomain:WISErrorDomain
                                             code:(NSInteger)ErrorCodeNetworkTransmission
                                         userInfo:userInfoAll];
            break;
            
        default:
            err = nil;
            break;
    }
    
    return err;
}


/// method works well on windows style file URL, because on windows, the separator of path is "\", while on Mac, the separator is "/"
- (WISFileInfo *) produceFileInfoWithFileRemoteURL:(NSString *)url {
    WISFileInfo *fileInfo = [[WISFileInfo alloc] init];
    
    NSArray *fileFullNameComponent = [url componentsSeparatedByString:@"\\"];
    NSString *fileNameWithExtension = [fileFullNameComponent objectAtIndex:(fileFullNameComponent.count - 1)];
    
    fileInfo.fileType = [fileNameWithExtension pathExtension];
    fileInfo.fileName = [[fileNameWithExtension componentsSeparatedByString:@"."] objectAtIndex:0];
    fileInfo.fileRemoteLocation = url;
    fileInfo.fileOnDeviceLocation = @"";
    
    return fileInfo;
}

#pragma mark - support method: image storage

@end
