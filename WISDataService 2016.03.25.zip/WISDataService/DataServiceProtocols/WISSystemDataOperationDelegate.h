//
//  WISSystemDataOperationDelegate.h
//  WISConnect
//
//  Created by Jingwei Wu on 2/28/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#ifndef WISSystemDataOperationDelegate_h
#define WISSystemDataOperationDelegate_h

#endif /* WISSystemDataOperationDelegate_h */





@protocol WISSystemDataOperationDelegate <NSObject>

@required
/// SignIn
- (void) signInSucceeded;
- (void) signInFailedWithError:(NSError *) error;

/// Upload images
- (void) uploadImagesSucceeded;
- (void) uploadImagesFailedWithError:(NSError *) error;

/// Download images
- (void) downloadImagesSucceeded;
- (void) downloadImagesFailedWithError:(NSError *) error;

@optional
/// SignIn
- (void) signInSucceededwithResponsedData:(NSData *) responsedData;
- (void) signInFailedWithError:(NSError *) error andResponsedData:(NSData *) responsedData;


/// Upload images
- (void) uploadImagesSucceededWithResponsedData:(NSData *) responsedData;
- (void) uploadImagesFailedWithError:(NSError *) error andResponsedData:(NSData *) responsedData;


/// Download images
- (void) downloadImagesSucceededWithResponsedData:(NSData *) responsedData;
- (void) downloadImagesFailedWithError:(NSError *) error andResponsedData:(NSData *) responsedData;

@end