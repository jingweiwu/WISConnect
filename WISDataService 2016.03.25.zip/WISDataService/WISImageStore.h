//
//  WISImageStore.h
//  WISConnect
//
//  Created by Jingwei Wu on 2/25/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#ifndef WISImageStore_h
#define WISImageStore_h


#import "WISLocalDocumentImageStore.h"


#endif /* WISImageStore_h */

