//
//  Header.h
//  WISConnect
//
//  Created by Jingwei Wu on 2/28/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#ifndef WISSystemDataNotification_h
#define WISSystemDataNotification_h

#import <Foundation/Foundation.h>

#endif /* WISSystemDataNotification_h */


FOUNDATION_EXPORT NSString *const WISSystemSignInSucceededNotification;
FOUNDATION_EXPORT NSString *const WISSystemSignInFailedNotification;

// FOUNDATION_EXPORT NSString *const WISSystemIncorrectResponsedDataNotification;

FOUNDATION_EXPORT NSString *const WISUploadImagesSucceededNotification;
FOUNDATION_EXPORT NSString *const WISUploadImagesFailedNotification;

FOUNDATION_EXPORT NSString *const WISDownloadImagesSucceededNotification;
FOUNDATION_EXPORT NSString *const WISDownloadImagesFailedNotification;
