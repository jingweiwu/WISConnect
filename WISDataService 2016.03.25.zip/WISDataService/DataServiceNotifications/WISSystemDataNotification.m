//
//  WISSystemDataNotification.m
//  WISConnect
//
//  Created by Jingwei Wu on 2/28/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#import "WISSystemDataNotification.h"


NSString *const WISSystemSignInSucceededNotification = @"WISSystemSignInSucceededNotification";
NSString *const WISSystemSignInFailedNotification = @"WISSystemSignInFailedNotification";

// NSString *const WISSystemIncorrectResponsedDataNotification = @"WISSystemIncorrectResponsedDataNotification";

NSString *const WISUploadImagesSucceededNotification = @"WISUploadImagesSucceededNotification";
NSString *const WISUploadImagesFailedNotification = @"WISUploadImagesFailedNotification";

NSString *const WISDownloadImagesSucceededNotification = @"WISDownloadImagesSucceededNotification";
NSString *const WISDownloadImagesFailedNotification = @"WISDownloadImagesFailedNotification";