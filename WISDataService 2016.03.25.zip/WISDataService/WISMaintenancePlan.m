//
//  WISMaintenancePlan.m
//  WISConnect
//
//  Created by Jingwei Wu on 2/22/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#import "WISMaintenancePlan.h"
#import "WISFileInfo.h"

@interface WISMaintenancePlan ()

@end

@implementation WISMaintenancePlan

-(instancetype)init {
    return [self initWithDescription:@""
                  estimateEndingTime:[NSDate date]
                        participants:[NSMutableArray array]
                       andImagesInfo:[NSMutableDictionary dictionary]];
}

- (instancetype)initWithDescription:(NSString*) description
                 estimateEndingTime:(NSDate*) estimatedEndingTime
                       participants:(NSMutableArray *) participants
                      andImagesInfo:(NSMutableDictionary<NSString *, WISFileInfo *> *)imagesInfo; {
    if(self = [super init]) {
        _planDescription = description;
        _estimatedEndingTime = estimatedEndingTime;
        _participants = participants;
        _imagesInfo = [NSMutableDictionary dictionaryWithDictionary:imagesInfo];
    }
    return self;
}

- (id)copyWithZone:(NSZone *)zone {
    WISMaintenancePlan *maintenancePlan = [[[self class] allocWithZone:zone] initWithDescription:[self.planDescription copy]
                                                                              estimateEndingTime:[self.estimatedEndingTime copy]
                                                                                    participants:[self.participants copy]
                                                                                   andImagesInfo:[self.imagesInfo copy]];
    return maintenancePlan;
}

- (id)mutableCopyWithZone:(NSZone *)zone {
    WISMaintenancePlan *maintenancePlan = [[[self class] allocWithZone:zone] initWithDescription:[self.planDescription copy]
                                                                              estimateEndingTime:[self.estimatedEndingTime copy]
                                                                                    participants:[NSMutableArray arrayWithArray:self.participants]
                                                                                   andImagesInfo:[NSMutableDictionary dictionaryWithDictionary:self.imagesInfo]];
    return maintenancePlan;
}


@end
