//
//  WISMaintenancePlan.h
//  WISConnect
//
//  Created by Jingwei Wu on 2/22/16.
//  Copyright © 2016 Jingwei Wu. All rights reserved.
//

#import <Foundation/Foundation.h>

@class WISFileInfo;

@interface WISMaintenancePlan : NSObject <NSCopying, NSMutableCopying>

@property (readwrite, strong) NSString *planDescription;
@property (readwrite, strong) NSDate *estimatedEndingTime;
@property (readwrite, strong) NSMutableArray *participants;
@property (readwrite, strong) NSMutableDictionary<NSString *, WISFileInfo *> *imagesInfo;

- (instancetype)init; // __attribute__((unavailable("init method not available")));

- (instancetype)initWithDescription:(NSString*) description
                 estimateEndingTime:(NSDate*) estimatedEndingTime
                       participants:(NSMutableArray *) participants
                      andImagesInfo:(NSMutableDictionary<NSString *, WISFileInfo *> *)imagesInfo;

@end
